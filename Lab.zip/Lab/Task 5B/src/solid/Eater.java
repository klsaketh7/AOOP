package solid;

public interface Eater {
    void eat();
}
