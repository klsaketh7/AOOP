package solid;

public interface Worker {
    void work();
}
