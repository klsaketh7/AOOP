package solid;

public class Robot implements Worker {
    @Override
    public void work() {
        System.out.println("Working");
    }
}
