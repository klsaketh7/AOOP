package solid;

public class Bird {
    public void fly() {
        System.out.println("Flying");
    }
}
