package Pack;

public interface Bidder {
    void update(String itemName, String event);
    String getName();
}