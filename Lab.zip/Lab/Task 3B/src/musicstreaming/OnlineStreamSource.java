package musicstreaming;

public class OnlineStreamSource implements MusicSource {
    public void playMusic() {
        System.out.println("Streaming online music.");
    }
}
