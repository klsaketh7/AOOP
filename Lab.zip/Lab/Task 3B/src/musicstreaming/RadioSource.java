package musicstreaming;

public class RadioSource implements MusicSource {
    public void playMusic() {
        System.out.println("Playing radio station.");
    }
}
