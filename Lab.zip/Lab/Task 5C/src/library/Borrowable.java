package library;

public interface Borrowable {
    boolean borrowItem();
    boolean returnItem();
}
