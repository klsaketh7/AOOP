package ridesharing.vehicles;

public interface Vehicle {
    void ride();
}
