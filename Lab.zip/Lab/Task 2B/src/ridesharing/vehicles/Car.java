package ridesharing.vehicles;

public class Car implements Vehicle {
    public void ride() {
        System.out.println("Riding a car.");
    }
}
