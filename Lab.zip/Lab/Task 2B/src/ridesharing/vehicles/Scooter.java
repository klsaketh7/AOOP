package ridesharing.vehicles;

public class Scooter implements Vehicle {
    public void ride() {
        System.out.println("Riding a scooter.");
    }
}

